<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tema extends MY_Controller {

	public function index()
	{
		$this->load->view('v_index');
	}

}

/* End of file Tema.php */
/* Location: ./application/modules/tema/controllers/Tema.php */