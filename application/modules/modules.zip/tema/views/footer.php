<!-- /.content-wrapper -->
<footer class="main-footer">
  <div class="pull-right hidden-xs">
    <b>E-Monitoring</b> 1.0
  </div>
  <strong>Copyright &copy; 2020 <a href="https://pengenngoding.com">E-Monitoring</a>.</strong> All rights
  reserved.
</footer>
